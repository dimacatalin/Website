var tata;
window.onload = function()
{
 var button = document.querySelectorAll(".getticket");
 var inputRange = document.createElement("input");
  
  var x = document.getElementById('hohoho');
  var bx = document.createElement("div");
  bx.style.backgroundColor = "#990000";
  bx.style.width = "20px";
  bx.style.height = "20px"; 
  bx.style.position = "absolute";


  //mouse event
  x.onmouseenter = function()
  {
     x.appendChild(bx);
  }
  
  x.onmousemove = function(event){
      bx.style.left = event.pageX+"px";
      bx.style.top = event.pageY+"px";
  }

  x.onmouseleave = function(){
    bx.remove();
  }

  function startTime() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  // add a zero in front of numbers<10
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById("txt").innerHTML = h + ":" + m + ":" + s;
  var t = setTimeout(function(){ startTime() }, 500);
}
startTime();

function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}

  //animatie

  var container = document.getElementById("container");
  var elem = document.getElementById("animate");
  var id = setInterval(frame, 5);
  var maxDistToTravel = container.offsetWidth - elem.offsetWidth; // container width - red box width
  var pos = 0;
  var end = maxDistToTravel;
  var direction = 1;
  function frame() { 
   if (pos === end) {
     direction *= -1; // reverses current direction
     end = Math.abs(maxDistToTravel - end); 
   }
   pos += direction;
   elem.style.left = pos + "px";
  }




 for(const buton of button)
 {
 buton.onclick = function()
 {
  buton.style.display = "none";

  //input
  game = buton.parentElement;
  var div3 = document.createElement("div");

  var inputText = document.createElement("input");
  inputText.setAttribute("type", "text");
  div3.append("Name: ");
  div3.appendChild(document.createElement("br"));
  div3.appendChild(inputText);
  div3.appendChild(document.createElement("br"));

  game.appendChild(div3);

  //checkbox

  div = document.createElement("div");

  div.append("What food would you like? ");
  div.appendChild(document.createElement("br"));

  checkbox1 = document.createElement("input");
  checkbox1.setAttribute("type", "checkbox");
  div.appendChild(checkbox1);
  div.append("Quesadilla");
  div.appendChild(document.createElement("br"));

  checkbox2 = document.createElement("input");
  checkbox2.setAttribute("type", "checkbox");
  div.appendChild(checkbox2);
  div.append("Cheeseburger");
  div.appendChild(document.createElement("br"));

  checkbox3 = document.createElement("input");
  checkbox3.setAttribute("type", "checkbox");
  div.appendChild(checkbox3);
  div.append("Hotdog");
  div.appendChild(document.createElement("br"));

  game.appendChild(div);

  //inputrange

  var div1 = document.createElement("div");
  inputRange.setAttribute("type", "range");
  inputRange.setAttribute("min", "1");
  inputRange.setAttribute("max", "10");
  inputRange.setAttribute("value", "1");
  div1.append("Row number: ");
  div1.appendChild(document.createElement("br"));
  div1.appendChild(inputRange);
  div1.appendChild(document.createElement("br"));

  var p = document.createElement("p");
  p.style.fontSize = "0.7em";
  p.style.textIndent = "0";
  p.style.padding = p.style.margin = "0";
  p.innerHTML = inputText.value;
  div1.appendChild(p);

  game.appendChild(div1);
  //radio

  div2 = document.createElement("div");

  div2.append("Ticket type: ");
  div2.appendChild(document.createElement("br"));

  radio1 = document.createElement("input");
  radio1.setAttribute("type", "radio");
  radio1.setAttribute("name", "echipa");
  radio1.setAttribute("checked", "true");
  div2.appendChild(radio1);
  div2.append("VIP");
  div2.appendChild(document.createElement("br"));

  radio2 = document.createElement("input");
  radio2.setAttribute("type", "radio");
  radio2.setAttribute("name", "echipa");
  div2.appendChild(radio2);
  div2.append("NORMAL");
  div2.appendChild(document.createElement("br"));

  game.appendChild(div2);
  game.appendChild(document.createElement("br"));

  //textarea

  bro = document.createElement("textarea");
  bro.value = "How do you think the game will go?"
  game.appendChild(bro)


  game.appendChild(document.createElement("br"));

  game.appendChild(document.createTextNode("Who will score the most?"))
  game.appendChild(document.createElement("br"));

  frt = document.createElement("select")
  opt1 = document.createElement("option")
  opt1.value = "B.Ingram"
  opt1.innerHTML = "B.Ingram"
  opt2 = document.createElement("option")
  opt2.value = "L.Ball"
  opt2.innerHTML = "L.Ball"
  opt3 = document.createElement("option")
  opt3.value = "Z.Williamson"
  opt3.innerHTML = "Z.Williamson"
  opt4 = document.createElement("option")
  opt4.value = "JJ.Reddick"
  opt4.innerHTML = "JJ.Reddick"

  frt.appendChild(opt1)
  frt.appendChild(opt2)
  frt.appendChild(opt3)
  frt.appendChild(opt4)

  game.appendChild(frt);

  buto = document.createElement("button");
  buto.innerHTML = "submit"
  
  game.appendChild(buto)
  game.insertBefore(document.createElement("br"),buto);
   daddy = game.parentElement;

  buto.onclick = function()
  {
      daddy.removeChild(daddy.childNodes[1]);
      alert("You bought the ticket");
  }
}
}
  tata = document.getElementById("tata");

  document.onkeydown = function()
  {
    if(event.key=="i" && event.altKey==true)
    {
      console.log("adev");
      for(j=button.length-2;j>=0;j--)
        tata.appendChild(button[j].parentElement.parentElement.parentElement);
    }
  }

inputRange.onchange = () => {
  inputRange.parentElement.lastChild.innerHTML = inputRange.value;
};
}




